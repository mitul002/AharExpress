import 'model.dart';

void main() {
  var obj = Model();
  obj.setName = "Piash";
  print(obj.getName);
}
