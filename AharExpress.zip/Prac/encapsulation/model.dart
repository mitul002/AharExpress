class Model {
  String name = "ehat";
  String get getName {
    return name;
  }

  set setName(String a) {
    name = a;
  }
}
