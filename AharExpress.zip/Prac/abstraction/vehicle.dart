abstract class vehicle
{
  void start()
  {
    print("vehicle started.");
  }
  void stop()
  {
    print("Vehicle Stopped.");
  }
}