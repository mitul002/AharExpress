import 'carVehicle.dart';

void main() {
  var obj = carVehicle();
  obj.start();
  obj.stop();
}
