import 'vehicle.dart';

class carVehicle extends vehicle
{
  @override
  void start()
  {
    print("Car Started.");
  }
}