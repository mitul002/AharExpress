import 'Son.dart';

void main() {
  var obj = Son();
  obj.methodOne();
  obj.plus();
}
