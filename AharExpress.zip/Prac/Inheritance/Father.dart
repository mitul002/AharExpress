class Father
{
  int age = 50;
  void methodOne()
  {
    print("This method one.");
  }
  void methodTwo()
  {
    print("This method two.");
  }
}