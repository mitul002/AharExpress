import 'Father.dart';

class Son extends Father {


  //add
  void plus()
  {
    print("This is plus.");
  }
}