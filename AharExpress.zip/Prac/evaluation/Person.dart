class Person
{
  String name = "Nisa";
  int age = 30;
  String gender = "Male";

  void display_info()
  {
    print("Name: $name");
    print("Age: $age");
    print("Gender: $gender");
  }
}