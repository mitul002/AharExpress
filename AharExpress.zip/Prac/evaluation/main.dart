import 'Student.dart';

void main() {
  var std = Student();
  std.display_info();
}
